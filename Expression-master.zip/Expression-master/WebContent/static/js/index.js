

        var sf = new Snowflakes({
          color: "#ffffff",
          count: 75,
          minOpacity: 0.2,
          maxOpacity: 0.6
        });